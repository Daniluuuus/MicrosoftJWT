﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfAppChampion
{
    /// <summary>
    /// Логика взаимодействия для PageEmploye.xaml
    /// </summary>
    public partial class PageEmploye : Page
    {
        public PageEmploye()
        {
            InitializeComponent();
            CBDepartments.ItemsSource = PersonnelManagementEntities.GetContext().ПодразделенияОрганизации.ToList();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new PageMainWindow());
        }

        private void CBDepartments_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CBDepartments.SelectedItem is ПодразделенияОрганизации selectedDepartment)
            {
                LoadEmployees(selectedDepartment.ID_Подразделения);
            }
        }

        private void LoadEmployees(int departmentId)
        {
            using (var context = new PersonnelManagementEntities())
            {
                var employees = (from orgStruct in context.ОрганизационнаяСтруктура
                                 join employee in context.Сотрудники on orgStruct.ID_сотрудника equals employee.ID_сотрудника
                                 where orgStruct.ID_подразделения == departmentId
                                 select employee).ToList();

                foreach (var emp in employees)
                {
                    Console.WriteLine($"Сотрудник: {emp.Фамилия} {emp.Имя}");
                }

                DGEmployeeInfo.ItemsSource = employees;
            }
        }

        private void OpenEmployeeCard_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button)
            {
                var employee = button.Tag as Сотрудники;
                EmployeeCardWindow employeeCard = new EmployeeCardWindow(employee);
                employeeCard.ShowDialog();
            }
        }


    }
}

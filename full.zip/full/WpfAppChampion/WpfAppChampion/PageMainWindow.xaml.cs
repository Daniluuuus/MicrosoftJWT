﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfAppChampion
{
    /// <summary>
    /// Логика взаимодействия для PageMainWindow.xaml
    /// </summary>
    public partial class PageMainWindow : Page
    {
        public PageMainWindow()
        {
            InitializeComponent();
        }

        private void ButtonEmployeeCheck_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new PageEmploye());
        }

        private void ButtonOrgStructCheck_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new PageOrgStructMain());
        }

        private void ButtonEmployeeAdd_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new PageAddEmploye());
        }
    }
}

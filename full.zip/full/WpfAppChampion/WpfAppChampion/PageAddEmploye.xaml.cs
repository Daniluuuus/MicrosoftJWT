﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfAppChampion
{
    /// <summary>
    /// Логика взаимодействия для PageAddEmploye.xaml
    /// </summary>
    public partial class PageAddEmploye : Page
    {
        private Сотрудники _newEmploye = new Сотрудники();
        public PageAddEmploye()
        {
            InitializeComponent();
            DataContext = _newEmploye;
        }

        private void BackBtn_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new PageMainWindow());
        }

        private void SaveEmployeBtn_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder sbErrors = new StringBuilder();

            // Проверка на обязательные поля
            if (string.IsNullOrWhiteSpace(_newEmploye.Фамилия))
                sbErrors.AppendLine("Введите имя");
            if (string.IsNullOrWhiteSpace(_newEmploye.Имя))
                sbErrors.AppendLine("Введите фамилию");
            if (string.IsNullOrWhiteSpace(_newEmploye.Отчество_))
                sbErrors.AppendLine("Введите отчество");
            if (string.IsNullOrWhiteSpace(_newEmploye.Должность))
                sbErrors.AppendLine("Введите должность");
            if (string.IsNullOrWhiteSpace(_newEmploye.Телефон_рабочий_))
                sbErrors.AppendLine("Введите телефон");
            if (string.IsNullOrWhiteSpace(_newEmploye.Кабинет))
                sbErrors.AppendLine("Введите кабинет");
            if (string.IsNullOrWhiteSpace(_newEmploye.Почта_))
                sbErrors.AppendLine("Введите почту");

            if (sbErrors.Length > 0)
            {
                MessageBox.Show(sbErrors.ToString());
                return;
            }

            if (_newEmploye.ID_сотрудника == 0)
                PersonnelManagementEntities.GetContext().Сотрудники.Add(_newEmploye);

            try
            {
                PersonnelManagementEntities.GetContext().SaveChanges();
                MessageBox.Show("Информация сохранена");
                Manager.MainFrame.Navigate(new PageMainWindow());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}

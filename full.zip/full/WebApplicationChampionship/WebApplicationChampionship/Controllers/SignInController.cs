﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using static WebApplicationChampionship.BaseClass;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

[Route("api/v1/[controller]")]
[ApiController]
public class SignInController : ControllerBase
{
    private readonly IConfiguration _configuration;

    public SignInController(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    [HttpPost]
    public IActionResult SignIn([FromBody] User user)
    {
        var existingUser = InMemoryData.Users.FirstOrDefault(u => u.Name == user.Name && u.Password == user.Password);

        if (existingUser == null)
        {
            return Ok(new { token = (string)null });
        }

        // Генерация JWT токена
        var token = GenerateJwtToken(existingUser);
        return Ok(new { token });
    }

    private string GenerateJwtToken(User user)
    {
        var jwtSettings = _configuration.GetSection("Jwt");

        var jwtKey = jwtSettings["Key"];
        if (string.IsNullOrEmpty(jwtKey))
        {
            throw new InvalidOperationException("JWT Key не настроен.");
        }

        var key = new SymmetricSecurityKey(Encoding.ASCII.GetBytes(jwtKey));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer: jwtSettings["Issuer"],
            audience: jwtSettings["Audience"],
            claims: new[] { new Claim(ClaimTypes.Name, user.Name) },
            expires: DateTime.UtcNow.AddHours(1),
            signingCredentials: credentials
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}

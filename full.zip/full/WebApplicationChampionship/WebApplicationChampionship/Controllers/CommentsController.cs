﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static WebApplicationChampionship.BaseClass;

[Route("api/v1/Document/{documentId}/[controller]")]
[ApiController]
public class CommentsController : ControllerBase
{
    [HttpGet]
    public IActionResult GetComments(int documentId)
    {
        var comments = InMemoryData.Comments.Where(c => c.DocumentId == documentId).ToList();
        if (comments.Count == 0)
        {
            return NotFound(new
            {
                timestamp = DateTimeOffset.UtcNow.ToUnixTimeSeconds(),
                message = "Не найдены комментарии для документа",
                errorCode = 2344
            });
        }
        return Ok(comments);
    }

    [HttpPost]
    public IActionResult AddComment(int documentId, [FromBody] Comment comment)
    {
        if (!InMemoryData.Documents.Any(d => d.Id == documentId))
        {
            return NotFound(new { message = "Документ не найден", errorCode = 2345 });
        }

        comment.Id = InMemoryData.Comments.Count + 1;
        comment.DocumentId = documentId;
        comment.DateCreated = DateTime.UtcNow;
        comment.DateUpdated = DateTime.UtcNow;

        InMemoryData.Comments.Add(comment);

        return Ok(comment);
    }
}

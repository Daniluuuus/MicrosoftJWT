﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static WebApplicationChampionship.BaseClass;


[Route("api/v1/[controller]")]
[ApiController]
public class DocumentsController : ControllerBase
{
    [HttpGet]
    public IActionResult GetDocuments()
    {
        if (InMemoryData.Documents == null || !InMemoryData.Documents.Any())
        {
            return NotFound(new { message = "Документы не найдены." });
        }

        return Ok(InMemoryData.Documents);
    }
}

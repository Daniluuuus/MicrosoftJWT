﻿namespace WebApplicationChampionship
{
    public class BaseClass
    {
        public class User
        {
            public string Name { get; set; } = string.Empty;
            public string Password { get; set; } = string.Empty;
        }

        public class Document
        {
            public int Id { get; set; }
            public string Title { get; set; } = string.Empty;
            public DateTime DateCreated { get; set; }
            public DateTime DateUpdated { get; set; }
            public string Category { get; set; } = string.Empty;
            public bool HasComments { get; set; }
        }

        public class Comment
        {
            public int Id { get; set; }
            public int DocumentId { get; set; }
            public string Text { get; set; } = string.Empty;
            public DateTime DateCreated { get; set; }
            public DateTime DateUpdated { get; set; }
            public string AuthorName { get; set; } = string.Empty;
            public string AuthorPosition { get; set; } = string.Empty;
        }

        public static class InMemoryData
        {
            public static List<User> Users = new()
            {
                new User { Name = "admin", Password = "admin123" }
            };

            public static List<Document> Documents = new()
            {
                new Document { Id = 1, Title = "Документ 1", DateCreated = DateTime.Now, DateUpdated = DateTime.Now, Category = "Категория 1", HasComments = true },
                new Document { Id = 2, Title = "Документ 2", DateCreated = DateTime.Now, DateUpdated = DateTime.Now, Category = "Категория 2", HasComments = false }
            };

            public static List<Comment> Comments = new()
            {
                new Comment { Id = 1, DocumentId = 1, Text = "Первый комментарий к Документу 1", DateCreated = DateTime.Now, DateUpdated = DateTime.Now, AuthorName = "Данил", AuthorPosition = "Программист" },
                new Comment { Id = 2, DocumentId = 2, Text = "Второй комментарий к Документу 2", DateCreated = DateTime.Now, DateUpdated = DateTime.Now, AuthorName = "Кирилл", AuthorPosition = "Учитель" }
            };

        }

    }
}
